export const SET_ORDER_ITEMS = "setOrderItems";
export const SET_TOTAL_AMOUNT = "setTotalAmount";
export const GET_ORDER_DETAILS = "getOrderDetails";

