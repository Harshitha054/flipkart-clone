export const GET_PRODUCTS="getProducts";
export const GET_PRODUCT_BY_ID="getProductById";