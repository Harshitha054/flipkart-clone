export const ADD_TO_CART="addToCart";
export const REMOVE_FROM_CART="removeFromCart";
export const CLEAR_CART="clearCart";
export const UPDATE_QTY="updateQty";
export const SET_CART_ITEMS="setCartItems";

