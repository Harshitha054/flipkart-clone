export const UPDATE_ADDRESS_COMPONENT_STATE = "updateAddressComponentState";
export const ADD_NEW_ADDRESS = "addNewAddress";
export const SET_ADDRESSES = "setAddresses";
export const REMOVE_ADDRESS = "removeAddress";
