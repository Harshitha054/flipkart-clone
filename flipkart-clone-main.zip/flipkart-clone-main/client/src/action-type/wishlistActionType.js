export const ADD_TO_WISHLIST="addToWishList";
export const REMOVE_FROM_WISHLIST="removeFromWishlist";
export const SET_WISHLIST_ITEMS="setWishlistItems";

